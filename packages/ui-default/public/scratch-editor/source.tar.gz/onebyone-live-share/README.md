# Classroom view bridge

This optional bridge keeps the Scratch iframe's opaque sandbox. It only starts recording after a verified parent handshake and stops when the connection lease expires.

Corresponding source: https://github.com/tb5519/Hydro-tibor/tree/master/packages/ui-default/components/live_share

Build using esbuild 0.25.2 from this directory:

`esbuild frame_capture.ts --bundle --format=iife --platform=browser --target=es2020 --minify --legal-comments=inline --outfile=live-share-frame.js`

The repository's build/scratch/build-live-share-frame.mjs hashes the output, updates editor.html and the release manifest. Vendored licenses are in vendor.LICENSE.txt.
