import bindAll from 'lodash.bindall';
import {loadLibrary, prepareAssets} from '../lib/onebyone-library-loader';
import PropTypes from 'prop-types';
import React from 'react';
import {defineMessages, injectIntl, intlShape} from 'react-intl';
import VM from 'scratch-vm';

import {getBackdropLibrary} from '../lib/libraries/tw-async-libraries';
import backdropTags from '../lib/libraries/backdrop-tags';
import LibraryComponent from '../components/library/library.jsx';

const messages = defineMessages({
    libraryTitle: {
        defaultMessage: 'Choose a Backdrop',
        description: 'Heading for the backdrop library',
        id: 'gui.costumeLibrary.chooseABackdrop'
    }
});


class BackdropLibrary extends React.Component {
    constructor (props) {
        super(props);
        bindAll(this, [
            'handleItemSelect'
        ]);
        this.state = {
            data: null
        };
    }
    componentDidMount () {
        this.loadLibrary = () => loadLibrary(this, getBackdropLibrary);
        this.loadLibrary();
    }
    componentWillUnmount () {
        this.onebyoneLoadToken = null;
    }
    handleItemSelect (item) {
        const vmBackdrop = {
            name: item.name,
            rotationCenterX: item.rotationCenterX,
            rotationCenterY: item.rotationCenterY,
            bitmapResolution: item.bitmapResolution,
            skinId: null
        };
        // Do not switch to stage, just add the backdrop
        return prepareAssets(this.props.vm, [item.md5ext]).then(() =>
            this.props.vm.addBackdrop(item.md5ext, vmBackdrop));
    }
    render () {
        return (
            <LibraryComponent
                data={this.state.data}
                id="backdropLibrary"
                tags={backdropTags}
                title={this.props.intl.formatMessage(messages.libraryTitle)}
                onItemSelected={this.handleItemSelect}
                libraryError={this.state.libraryError}
                previewError={this.state.previewError}
                onRetryLoad={this.loadLibrary}
                onOpenPresetLibrary={() => {
                    if (window.onebyoneOpenPresetLibrary && window.onebyoneOpenPresetLibrary('backdrop')) this.props.onRequestClose();
                }}
                onRequestClose={this.props.onRequestClose}
            />
        );
    }
}

BackdropLibrary.propTypes = {
    intl: intlShape.isRequired,
    onRequestClose: PropTypes.func,
    vm: PropTypes.instanceOf(VM).isRequired
};

export default injectIntl(BackdropLibrary);
