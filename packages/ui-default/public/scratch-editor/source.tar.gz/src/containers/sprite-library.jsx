import bindAll from 'lodash.bindall';
import {loadLibrary, prepareAssets} from '../lib/onebyone-library-loader';
import PropTypes from 'prop-types';
import React from 'react';
import {injectIntl, intlShape, defineMessages} from 'react-intl';
import VM from 'scratch-vm';

import {getSpriteLibrary} from '../lib/libraries/tw-async-libraries';
import randomizeSpritePosition from '../lib/randomize-sprite-position';
import spriteTags from '../lib/libraries/sprite-tags';

import LibraryComponent from '../components/library/library.jsx';

const messages = defineMessages({
    libraryTitle: {
        defaultMessage: 'Choose a Sprite',
        description: 'Heading for the sprite library',
        id: 'gui.spriteLibrary.chooseASprite'
    }
});

class SpriteLibrary extends React.PureComponent {
    constructor (props) {
        super(props);
        bindAll(this, [
            'handleItemSelect'
        ]);
        this.state = {
            data: null
        };
    }
    componentDidMount () {
        this.loadLibrary = () => loadLibrary(this, getSpriteLibrary);
        this.loadLibrary();
    }
    componentWillUnmount () {
        this.onebyoneLoadToken = null;
    }
    handleItemSelect (item) {
        // Randomize position of library sprite
        randomizeSpritePosition(item);
        return prepareAssets(this.props.vm, [...item.costumes, ...item.sounds].map(asset => asset.md5ext))
            .then(() => this.props.vm.addSprite(JSON.stringify(item))).then(() => {
            this.props.onActivateBlocksTab();
        });
    }
    render () {
        return (
            <LibraryComponent
                data={this.state.data}
                id="spriteLibrary"
                tags={spriteTags}
                title={this.props.intl.formatMessage(messages.libraryTitle)}
                onItemSelected={this.handleItemSelect}
                libraryError={this.state.libraryError}
                previewError={this.state.previewError}
                onRetryLoad={this.loadLibrary}
                onOpenPresetLibrary={() => {
                    if (window.onebyoneOpenPresetLibrary && window.onebyoneOpenPresetLibrary('sprite')) this.props.onRequestClose();
                }}
                onRequestClose={this.props.onRequestClose}
            />
        );
    }
}

SpriteLibrary.propTypes = {
    intl: intlShape.isRequired,
    onActivateBlocksTab: PropTypes.func.isRequired,
    onRequestClose: PropTypes.func,
    vm: PropTypes.instanceOf(VM).isRequired
};

export default injectIntl(SpriteLibrary);
