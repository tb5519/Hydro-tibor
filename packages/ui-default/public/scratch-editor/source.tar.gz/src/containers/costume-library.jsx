import bindAll from 'lodash.bindall';
import {loadLibrary, prepareAssets} from '../lib/onebyone-library-loader';
import PropTypes from 'prop-types';
import React from 'react';
import {defineMessages, injectIntl, intlShape} from 'react-intl';
import VM from 'scratch-vm';

import {getCostumeLibrary} from '../lib/libraries/tw-async-libraries';
import spriteTags from '../lib/libraries/sprite-tags';
import LibraryComponent from '../components/library/library.jsx';

const messages = defineMessages({
    libraryTitle: {
        defaultMessage: 'Choose a Costume',
        description: 'Heading for the costume library',
        id: 'gui.costumeLibrary.chooseACostume'
    }
});


class CostumeLibrary extends React.PureComponent {
    constructor (props) {
        super(props);
        bindAll(this, [
            'handleItemSelected'
        ]);
        this.state = {
            data: null
        };
    }
    componentDidMount () {
        this.loadLibrary = () => loadLibrary(this, getCostumeLibrary);
        this.loadLibrary();
    }
    componentWillUnmount () {
        this.onebyoneLoadToken = null;
    }
    handleItemSelected (item) {
        const vmCostume = {
            name: item.name,
            rotationCenterX: item.rotationCenterX,
            rotationCenterY: item.rotationCenterY,
            bitmapResolution: item.bitmapResolution,
            skinId: null
        };
        return prepareAssets(this.props.vm, [item.md5ext]).then(() =>
            this.props.vm.addCostumeFromLibrary(item.md5ext, vmCostume));
    }
    render () {
        return (
            <LibraryComponent
                data={this.state.data}
                id="costumeLibrary"
                tags={spriteTags}
                title={this.props.intl.formatMessage(messages.libraryTitle)}
                onItemSelected={this.handleItemSelected}
                libraryError={this.state.libraryError}
                previewError={this.state.previewError}
                onRetryLoad={this.loadLibrary}
                onOpenPresetLibrary={() => {
                    if (window.onebyoneOpenPresetLibrary && window.onebyoneOpenPresetLibrary('costume')) this.props.onRequestClose();
                }}
                onRequestClose={this.props.onRequestClose}
            />
        );
    }
}

CostumeLibrary.propTypes = {
    intl: intlShape.isRequired,
    onRequestClose: PropTypes.func,
    vm: PropTypes.instanceOf(VM).isRequired
};

export default injectIntl(CostumeLibrary);
